const path = require('path');

const configPath = path.join(__dirname, `scaffold/config`);
const env = process.env.NODE_ENV || 'localhost';

/**
 * Build the vue configuration
 * @param  {String} currentEnv The wanted environment
 * @return {Object} vue config
 */
function createConfig(currentEnv) {
  return require(path.join(configPath, currentEnv)).vueConfig;
}

module.exports = createConfig(env);
