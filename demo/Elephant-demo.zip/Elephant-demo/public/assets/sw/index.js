/**
 * Author: Li
 * Create Time: 2018-10-19 14:05
 * Description: sw
 */

workbox.setConfig({
  debug: true,
})

workbox.core.setLogLevel(workbox.core.LOG_LEVELS.silent);
