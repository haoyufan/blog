/**
 * Author: Li
 * Create Time: 2018-10-16 21:25
 * Description: oss
 */
const OSS = require('ali-oss')

module.exports = class OSSUtil {
  constructor(config) {
    this.client = new OSS(config)
  }

  async upload(params) {
    const bucket = params.bucket
      , name = params.name
      , content = params.content
      , options = params.options

    this.client.useBucket(bucket)

    return await this.client.put(name, content, options);
  }
}
