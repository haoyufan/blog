/**
 * Author: Li
 * Create Time: 2018-10-16 20:53
 * Description: config utils
 */
const merge = require('webpack-merge');
const path = require('path');
const configPath = path.join(__dirname, `../config`);
const cwd = process.cwd();
const env = process.env.NODE_ENV || 'localhost';

/**
 * build the configuration
 * @param config
 * @returns vue config
 */
module.exports.vueConfig = (config) => {
  return merge(require(path.join(configPath, env)).vueConfig, config);
}

/**
 * setting config
 * @param config
 * @returns {*}
 */
module.exports.config = (config) => {
  return merge(require(path.join(configPath, env)).config, config);
}

module.exports.cdn = () => {
  return require(path.join(configPath, 'cdn'));
}

module.exports.pkg = () => {
  return require(path.join(cwd, 'package.json'));
}
