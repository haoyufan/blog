/**
 * Author: Li
 * Create Time: 2018-10-16 20:41
 * Description: webpack utils
 */
const merge = require('webpack-merge');

module.exports.definePlugin = (config, options) => {
  config.plugin('define')
    .init((DefinePlugin, args) => new DefinePlugin(merge(...args, options)));
}

module.exports.updateLoader = (config, { rule, loader = "file-loader" }, _options) => {
  config.module
    .rule(rule)
    .use(loader)
    .tap(options => merge(options, _options));
}
