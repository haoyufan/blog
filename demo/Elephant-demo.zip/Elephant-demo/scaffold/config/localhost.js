/**
 * Author: Li
 * Create Time: 2018-10-16 11:07
 * Description: development
 */
const base = require('./base');
const pkg = require('./../../package');
const merge = require('webpack-merge');

// TODO update vue-cli NODE_ENV
if (!process.env.NODE_ENV !== 'development') {
  process.env.NODE_ENV = 'development';
}
module.exports.vueConfig = merge(base, {
  outputDir: `${base.outputDir}/development`,
  devServer: {
    host: '127.0.0.1',
    port: 8200,
    open: true,
    proxy: {
      [`/api/${pkg.apiVersion}/maopao`]: {
        target: 'http://47.100.29.47:8080',
        changeOrigin: true,
        pathRewrite: { [`^/api/${pkg.apiVersion}/maopao`]: '' },
      },
    }
  },
});
