/**
 * Author: Li
 * Create Time: 2018-10-16 11:07
 * Description: production
 */
const base = require('./base');
const cdn = require('./cdn');
const pkg = require('./../../package');
const path = require('path');
const merge = require('webpack-merge');
const ManifestPlugin = require('webpack-manifest-plugin');

// TODO update vue-cli pack production
if (!process.env.NODE_ENV !== 'production') {
  process.env.NODE_ENV = 'production';
}
const protocol = 'https';
const origin = `${protocol}://${cdn.host}`;
const env = `development`;
const envShortName = `d`;
const sourceMap = true;

const cdnPrefixPath = path.join(`${cdn.assetsPrefixDir}`, envShortName);
const cdnPath = (joinPath = '') => {
  return `${origin}${path.join(cdnPrefixPath, joinPath)}`;
};
const assetsPrefixDir = base.assetsDir;
const assetsPath = (joinPath = '') => {
  return path.join(assetsPrefixDir, joinPath);
};

const settingConfig = module.exports.config = {
  protocol,
  origin,
  env,
  envShortName,
  cdnPrefixPath,
  assetsPrefixDir,
  sourceMap,
  assetsPath,
  cdnPath,
  CDN_NAME: {
    js: cdnPath,
    jsChunk: cdnPath,
    css: cdnPath,
    cssChunk: cdnPath,
    img: cdnPath,
    svg: cdnPath,
    media: cdnPath,
    font: cdnPath,
  },
  FILE_NAME: {
    js: `${assetsPath('j/[name].[contenthash:8].js')}`,
    jsChunk: `${assetsPath('j/[name].ck.[contenthash:8].js')}`,
    css: `${assetsPath('c/[name].[contenthash:8].css')}`,
    cssChunk: `${assetsPath('c/[name].ck.[contenthash:8].css')}`,
    img: `${assetsPath('i/[name].[hash:8].[ext]')}`,
    svg: `${assetsPath('s/[name].[hash:8].[ext]')}`,
    media: `${assetsPath('m/[name].[hash:8].[ext]')}`,
    font: `${assetsPath('f/[name].[hash:8].[ext]')}`,
  },
};
module.exports.vueConfig = merge(base, {
  baseUrl: ``,
  outputDir: `${base.outputDir}/${settingConfig.env}`,
  assetsDir: settingConfig.assetsPrefixDir,
  filenameHashing: true,
  productionSourceMap: settingConfig.sourceMap,
  css: {
    sourceMap: settingConfig.sourceMap,
  },
  chainWebpack: config => {
    base.chainWebpack(config);

    //TODO build manifest json
    // config.plugin('manifest')
    //   .use(ManifestPlugin, [{
    //     fileName: 'project.json'
    //   }])
    config.output
      .filename(settingConfig.CDN_NAME.js(settingConfig.FILE_NAME.js))
      .chunkFilename(settingConfig.CDN_NAME.jsChunk(settingConfig.FILE_NAME.jsChunk));

    config.module
      .rule('images')
      .use('url-loader')
      .tap(options => merge(options, {
        fallback: {
          options: {
            name: settingConfig.CDN_NAME.img(settingConfig.FILE_NAME.img),
            // publicPath: settingConfig.CDN_NAME.img(),
          }
        }
      }));

    config.module
      .rule('svg')
      .use('file-loader')
      .tap(options => merge(options, {
        name: settingConfig.CDN_NAME.svg(settingConfig.FILE_NAME.svg),
        // publicPath: settingConfig.CDN_NAME.svg()
      }));

    config.module
      .rule('media')
      .use('url-loader')
      .tap(options => merge(options, {
        fallback: {
          options: {
            name: settingConfig.CDN_NAME.media(settingConfig.FILE_NAME.media),
            // publicPath: settingConfig.CDN_NAME.media()
          }
        }
      }));

    config.module
      .rule('fonts')
      .use('url-loader')
      .tap(options => merge(options, {
        fallback: {
          options: {
            name: settingConfig.CDN_NAME.font(settingConfig.FILE_NAME.font),
            // publicPath: settingConfig.CDN_NAME.font()
          }
        }
      }));

    // const updateStyleModulePublicPath = (rule) => {
    //   config.module
    //     .rule(rule)
    //     .oneOf('vue-modules')
    //     .use('extract-css-loader')
    //     .tap(options => merge(options, {
    //       publicPath: cdnPath()
    //     }));
    //
    //   config.module
    //     .rule(rule)
    //     .oneOf('vue')
    //     .use('extract-css-loader')
    //     .tap(options => merge(options, {
    //       publicPath: cdnPath()
    //     }));
    //
    //   config.module
    //     .rule(rule)
    //     .oneOf('normal-modules')
    //     .use('extract-css-loader')
    //     .tap(options => merge(options, {
    //       publicPath: cdnPath()
    //     }));
    //
    //   config.module
    //     .rule(rule)
    //     .oneOf('normal')
    //     .use('extract-css-loader')
    //     .tap(options => merge(options, {
    //       publicPath: cdnPath()
    //     }));
    // }
    //
    // updateStyleModulePublicPath('css');
    // updateStyleModulePublicPath('postcss');
    // updateStyleModulePublicPath('scss');
    // updateStyleModulePublicPath('sass');
    // updateStyleModulePublicPath('less');
    // updateStyleModulePublicPath('stylus');

    config.plugin('extract-css')
      .init((MiniCssExtractPlugin, args) => new MiniCssExtractPlugin(merge(...args, {
        filename: settingConfig.CDN_NAME.css(settingConfig.FILE_NAME.css),
        chunkFilename: settingConfig.CDN_NAME.cssChunk(settingConfig.FILE_NAME.cssChunk),
      })));
  }
});
