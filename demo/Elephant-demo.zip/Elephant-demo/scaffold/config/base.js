/**
 * Author: Li
 * Create Time: 2018-10-16 10:42
 * Description: base
 */
const webpackUtil = require('./../util/webpack');
const pkg = require('./../../package');
const merge = require('webpack-merge');

module.exports = {
  baseUrl: '/',
  assetsDir: 's/',
  outputDir: `dist/${pkg.version}`,
  pwa: {
    name: '冒泡',
    workboxOptions: {
      importWorkboxFrom: 'local',
      swDest: 'sw.js',
      precacheManifestFilename: 'cm.[manifestHash].js',
      clientsClaim: true,
      skipWaiting: true,
      importScripts: ['assets/sw/index.js'],
      exclude: [
        /assets\/icons\//,
        // /\.html$/,
        /\.map$/,
        /favicon\.ico$/,
        /manifest\.json$/
      ],
    },
    iconPaths: {
      favicon32: 'assets/icons/favicon32.png ',
      favicon16: 'assets/icons/favicon16.png ',
      appleTouchIcon: 'assets/icons/logo.png ',
      maskIcon: 'assets/icons/logo.png ',
      msTileImage: 'assets/icons/logo.png '
    }
  },
  chainWebpack: config => {
    // update DefinePlugin
    config.plugin('define')
      .init((DefinePlugin, args) => new DefinePlugin(merge(...args, {
        DOMAIN_URI: '"https://www.maopp.cn"',
        API_PREFIX: '"/api/v3/"',
      })));
  },
};
