/**
 * Author: Li
 * Create Time: 2018-10-16 11:25
 * Description:
 */

module.exports = {
  host: `cdn-static.maopp.cn`,
  assetsPrefixDir: '/elp',
  setting: {
    config: {
      region: `oss-cn-shanghai`,
      accessKeyId: `LTAIabWMrDyHUt4N`,
      accessKeySecret: `0ROuCkBc3vSYzAhqOmYhyVf6ji4MKV`
    },
    bucket: `static-maopao`
  }
};
