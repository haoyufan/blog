/**
 * Author: Li
 * Create Time: 2018-10-16 20:53
 * Description: deploy website
 */

const configUtil = require('./../util/config');
const OSSUtil = require('./../util/oss');
const path = require('path');
const glob = require('glob');
const async = require('async');
const fs = require('fs');

const vueConfig = configUtil.vueConfig();
const config = configUtil.config();
const cdn = configUtil.cdn();

// 本地资源 文件路径
const publishPath = path.resolve(process.cwd(), vueConfig.outputDir);
// 上传oss 路径
const prefixPath = `${config.cdnPrefixPath}/`;
// ossSetting
const ossSetting = cdn.setting.config;
// ossBucket
const ossBucket = cdn.setting.bucket;

/**
 * cdn static url
 * @param relovePath
 * @returns {string}
 */
function getCdnPath(resolvePath, fileNameParameter) {
  const fileName = path.basename(resolvePath);
  const isChunk = /.ck./.test(fileName);
  // TODO 获取 config 中的 file_name 包含 chunk
  const FileName = config.FILE_NAME[`${fileNameParameter}${isChunk ? 'Chunk' : ''}`];
  const cdnPathPrefix = config.cdnPrefixPath;
  const filePath = path.dirname(FileName);
  const cdnPath = path.join(cdnPathPrefix, filePath, fileName);
  console.log(cdnPath);
  return cdnPath;
}

/**
 * waterFallUploadFile
 * @param fileStreams
 * @param client
 * @param getOption
 * @param callback
 * @param isRemoveFile
 */
const waterfallUploadFiles = (fileList, client, getOption, callback, isRemoveFile = true) => {
  let pools = [];
  fileList.forEach(filePath => {
    pools.push(function (next) {
      console.log(`file >> ${filePath} << uploading!`);
      client.upload(getOption(filePath)).then(result => {
        if (isRemoveFile) {
          fs.unlinkSync(filePath);
          console.log(`file >> ${filePath} << upload success! delete file`);
        } else {
          console.log(`file >> ${filePath} << upload success!`)
        }
        next();
      }).catch(err => {
        console.log(`file >> ${filePath} << upload failed!`);
        console.log(err);
        next();
      })
    })
  })
  async.waterfall(pools, (err) => {
    if (err) {
      console.log(err)
    }
    callback && callback(err);
  })
};

const jsFileList = glob.sync(`${publishPath}/**/${config.assetsPrefixDir}/**/*.?(js|js.map)`);
const cssFileList = glob.sync(`${publishPath}/**/${config.assetsPrefixDir}/**/*.?(css|css.map)`);
const imgFileList = glob.sync(`${publishPath}/**/${config.assetsPrefixDir}/**/*.?(jpg|jpeg|png|gif|webp)`);
const svgFileList = glob.sync(`${publishPath}/**/${config.assetsPrefixDir}/**/*.?(svg)`);
const mediaFileList = glob.sync(`${publishPath}/**/${config.assetsPrefixDir}/**/*.?(mp4|webm|ogg|mp3|wav|flac|aac)`);
const fontFileList = glob.sync(`${publishPath}/**/${config.assetsPrefixDir}/**/*.?(woff|woff2|eot|ttf|otf)`);

const ossClient = new OSSUtil(Object.assign({}, ossSetting, { timeout: 1000 * 60 * 60 }));

async.waterfall([
  callback => {
    waterfallUploadFiles(jsFileList, ossClient, (filePath) => {
      return {
        content: filePath,
        bucket: ossBucket,
        name: getCdnPath(filePath, 'js'),
        options: {
          headers: {
            'content-type': 'application/javascript;charset=utf-8',
            'cache-control': 'max-age=315360000',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': '*',
          }
        }
      };
    }, callback)
  },
  callback => {
    waterfallUploadFiles(cssFileList, ossClient, (filePath) => {
      return {
        content: filePath,
        bucket: ossBucket,
        name: getCdnPath(filePath, 'css'),
        options: {
          headers: {
            'content-type': 'text/css;charset=utf-8',
            'cache-control': 'max-age=315360000',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': '*',
          }
        }
      };
    }, callback)
  },
  callback => {
    waterfallUploadFiles(imgFileList, ossClient, (filePath) => {
      const contentType = {
        [`jpg`]: 'image/jpg',
        [`jpeg`]: 'image/jpeg',
        [`png`]: 'image/png',
        [`gif`]: 'image/gif',
        [`webp`]: 'image/webp',
      }[path.extname(filePath).replace('\.', '')]
      return {
        content: filePath,
        bucket: ossBucket,
        name: getCdnPath(filePath, 'img'),
        options: {
          headers: {
            'content-type': contentType,
            'cache-control': 'max-age=315360000',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': '*',
          }
        }
      };
    }, callback)
  },
  callback => {
    waterfallUploadFiles(svgFileList, ossClient, (filePath) => {
      const contentType = {
        [`svg`]: 'image/svg+xml',
      }[path.extname(filePath).replace('\.', '')]
      return {
        content: filePath,
        bucket: ossBucket,
        name: getCdnPath(filePath, 'svg'),
        options: {
          headers: {
            'content-type': contentType,
            'cache-control': 'max-age=315360000',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': '*',
          }
        }
      };
    }, callback)
  },
  callback => {
    waterfallUploadFiles(mediaFileList, ossClient, (filePath) => {
      const contentType = {
        [`mp4`]: 'video/mp4',
        [`webm`]: 'video/webm',
        [`ogg`]: 'audio/ogg',
        [`mp3`]: 'audio/mp3',
        [`wav`]: 'audio/wav',
        [`flac`]: 'audio/flac',
        [`aac`]: 'audio/aac',
      }[path.extname(filePath).replace('\.', '')]
      return {
        content: filePath,
        bucket: ossBucket,
        name: getCdnPath(filePath, 'media'),
        options: {
          headers: {
            'content-type': contentType,
            'cache-control': 'max-age=315360000',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': '*',
          }
        }
      };
    }, callback)
  },
  callback => {
    waterfallUploadFiles(fontFileList, ossClient, (filePath) => {
      const contentType = {
        [`woff`]: 'application/x-font-woff',
        [`woff2`]: 'application/x-font-woff2',
        [`eot`]: 'application/vnd.ms-fontobject',
        [`ttf`]: 'application/x-font-truetype',
        [`otf`]: 'application/x-font-opentype',
      }[path.extname(filePath).replace('\.', '')]
      return {
        content: filePath,
        bucket: ossBucket,
        name: getCdnPath(filePath, 'font'),
        options: {
          headers: {
            'content-type': contentType,
            'cache-control': 'max-age=315360000',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': '*',
          }
        }
      };
    }, callback)
  }
], (err) => {
  if (err) {
    console.log(err)
  }
})
