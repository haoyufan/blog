<template>
  <div class="counter">
    <p>counter:{{count}}</p>
    <button @click="plus()">plus</button>
    <button @click="reduce()">reduce</button>
  </div>
</template>

<script lang="ts">
  import { Component, Vue } from 'vue-property-decorator';
  import { namespace } from 'vuex-class';

  const counter = namespace('counter');
  @Component({})
  export default class Counter extends Vue {
    @counter.State public count: any;
    @counter.Action public plus: any;
    @counter.Action public reduce: any;
  }
</script>
