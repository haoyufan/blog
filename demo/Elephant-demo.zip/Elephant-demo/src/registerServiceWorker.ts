/* tslint:disable:no-console */

import { register } from 'register-service-worker';

if (process.env.NODE_ENV === 'production') {
  register(`${process.env.BASE_URL}sw.js`, {
    ready() {
      console.log('初始化成功');
    },
    cached() {
      console.log('缓存内容成功,可离线访问');
    },
    updated() {
      console.log('网站发生新的变化,请刷新页面');
    },
    offline() {
      console.log('暂无网络,网站在离线模式下运行');
    },
    error(error) {
      console.error('注册 server-worker 发生错误', error);
    },
  });
}
