import { ActionContext } from 'vuex';

interface State {
  count: number;
}

const initState: State = {
  count: 0,
};

export default {
  namespaced: true,
  state: initState,
  getters: {},
  actions: {
    async plus(context: ActionContext<State, any>) {
      context.commit('plus');
    },
    async reduce(context: ActionContext<State, any>) {
      context.commit('reduce');
    },
  },
  mutations: {
    plus(state: any) {
      state.count++;
    },
    reduce(state: any) {
      state.count--;
    },
  },
};
